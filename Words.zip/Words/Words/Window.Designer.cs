﻿namespace Words
{
    partial class Window
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.butCountBasic = new System.Windows.Forms.Button();
            this.labSoruce = new System.Windows.Forms.Label();
            this.labResult = new System.Windows.Forms.Label();
            this.butClear = new System.Windows.Forms.Button();
            this.rtxResult = new System.Windows.Forms.RichTextBox();
            this.butClearAll = new System.Windows.Forms.Button();
            this.butCountStem = new System.Windows.Forms.Button();
            this.rtxSoruce = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // butCountBasic
            // 
            this.butCountBasic.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.butCountBasic.Location = new System.Drawing.Point(254, 100);
            this.butCountBasic.Name = "butCountBasic";
            this.butCountBasic.Size = new System.Drawing.Size(75, 23);
            this.butCountBasic.TabIndex = 2;
            this.butCountBasic.Text = "Count basic";
            this.butCountBasic.UseVisualStyleBackColor = true;
            this.butCountBasic.Click += new System.EventHandler(this.butCountBasic_Click);
            // 
            // labSoruce
            // 
            this.labSoruce.AutoSize = true;
            this.labSoruce.Location = new System.Drawing.Point(12, 9);
            this.labSoruce.Name = "labSoruce";
            this.labSoruce.Size = new System.Drawing.Size(34, 13);
            this.labSoruce.TabIndex = 0;
            this.labSoruce.Text = "Input:";
            // 
            // labResult
            // 
            this.labResult.AutoSize = true;
            this.labResult.Location = new System.Drawing.Point(12, 126);
            this.labResult.Name = "labResult";
            this.labResult.Size = new System.Drawing.Size(42, 13);
            this.labResult.TabIndex = 0;
            this.labResult.Text = "Output:";
            // 
            // butClear
            // 
            this.butClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.butClear.Location = new System.Drawing.Point(416, 100);
            this.butClear.Name = "butClear";
            this.butClear.Size = new System.Drawing.Size(75, 23);
            this.butClear.TabIndex = 4;
            this.butClear.Text = "Clear input";
            this.butClear.UseVisualStyleBackColor = true;
            this.butClear.Click += new System.EventHandler(this.butClear_Click);
            // 
            // rtxResult
            // 
            this.rtxResult.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtxResult.Location = new System.Drawing.Point(12, 142);
            this.rtxResult.Name = "rtxResult";
            this.rtxResult.Size = new System.Drawing.Size(560, 408);
            this.rtxResult.TabIndex = 6;
            this.rtxResult.Text = "";
            // 
            // butClearAll
            // 
            this.butClearAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.butClearAll.Location = new System.Drawing.Point(497, 100);
            this.butClearAll.Name = "butClearAll";
            this.butClearAll.Size = new System.Drawing.Size(75, 23);
            this.butClearAll.TabIndex = 5;
            this.butClearAll.Text = "Clear all";
            this.butClearAll.UseVisualStyleBackColor = true;
            this.butClearAll.Click += new System.EventHandler(this.butClearAll_Click);
            // 
            // butCountStem
            // 
            this.butCountStem.Location = new System.Drawing.Point(335, 100);
            this.butCountStem.Name = "butCountStem";
            this.butCountStem.Size = new System.Drawing.Size(75, 23);
            this.butCountStem.TabIndex = 3;
            this.butCountStem.Text = "Count stem";
            this.butCountStem.UseVisualStyleBackColor = true;
            this.butCountStem.Click += new System.EventHandler(this.butCountStem_Click);
            // 
            // rtxSoruce
            // 
            this.rtxSoruce.Location = new System.Drawing.Point(12, 25);
            this.rtxSoruce.Name = "rtxSoruce";
            this.rtxSoruce.Size = new System.Drawing.Size(560, 69);
            this.rtxSoruce.TabIndex = 1;
            this.rtxSoruce.Text = "";
            // 
            // Window
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 562);
            this.Controls.Add(this.rtxSoruce);
            this.Controls.Add(this.butCountStem);
            this.Controls.Add(this.butClearAll);
            this.Controls.Add(this.rtxResult);
            this.Controls.Add(this.butClear);
            this.Controls.Add(this.labResult);
            this.Controls.Add(this.labSoruce);
            this.Controls.Add(this.butCountBasic);
            this.MinimumSize = new System.Drawing.Size(300, 300);
            this.Name = "Window";
            this.Text = "Words count";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button butCountBasic;
        private System.Windows.Forms.Label labSoruce;
        private System.Windows.Forms.Label labResult;
        private System.Windows.Forms.Button butClear;
        private System.Windows.Forms.RichTextBox rtxResult;
        private System.Windows.Forms.Button butClearAll;
        private System.Windows.Forms.Button butCountStem;
        private System.Windows.Forms.RichTextBox rtxSoruce;
    }
}

